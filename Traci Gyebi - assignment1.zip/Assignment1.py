# this code reverses the user's input and calculates the length of the input as well
def rName():
    name = input("Please what is your name: ")  # this allows the username to input his or her name
    slength = str(len(name))  # this calculates the length of the name and also changes it to a string
    revname = name[::-1]  # this reverses the user's input
    print("The reversed input is " + revname + " and the length of the input is " + slength + ".")





